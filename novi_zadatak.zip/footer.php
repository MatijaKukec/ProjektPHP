<?php 

if(isset($baza)) $baza->close();
echo
'</div>
</body>
</html>
'
?>