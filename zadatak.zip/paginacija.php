<?php 

require_once ('baza.php');
//include ('paginacija.php');

//provjera da li se nalazi u bazi
//odredi vanje trenutačne stranice
//ukoliko ništa nemamo zapisano u URL -u, stranica se postavlja na 1,
//a ukoliko imamo zapisan broj u $_GET pos stavljamo ga u varijablu stranica
$stranica = (empty($_GET['stranica'])) ? 1 : (int) $_GET['stranica'];
//broj članaka koji će se prikazi vati po stranici
$brojPoStranici=3;
//brojanje koliko je stavki u bazi
$query = "SELECT COUNT (*) FROM korisnici";
$rezultat=$veza->query($query);

if ($rezultat) {
  $polje=$rezultat->fetch_row();
  $ukupno_korisnika=$polje[0];

  //odredivanje koliko ukupno imamo stranica
  $brojStranica=ceil($ukupno_korisnika/$brojPoStranici);
  //ukolko korisnik upiše u URL broj stranice koji ne postoji
  if ($stranica<1) $stranica=1;
  else if ($stranica>$brojStranica-1) $stranica=$brojStranica;
  //Odedivanje koji korisnici će se dohvatiti
  $odmak=$brojPoStranici*($stranica-1);
  //dohvaćanje korisnika ovisno o stranici na kojoj smo,
  //poredamo ih ASC, ukoliko želimo da idu od mladeg prema starijem stavimo DESC
  $query="SELECT*FROM korisnici ORDER BY id ASC LIMIT $brojPoStranici OFFSET $odmak" ;
  $rezultat=$veza->query($query, MYSQLI_STORE_RESULT);


  //paginaciju budemo ispisivali jedino ukoliko imamo više od jedne stranice
  if ($brojStranica>1) {
    echo "<div style='clear: left; '>";
    //ukoliko nismo na prvoj stranici ispisujemo prethodna,
    //kad bi bili na prvoj stranici ne bi ispisali prethodna
    echo '<ul class="pagination pagination-sm ">';
    if ($stranica>1){
      //prethodna je promjenjivi link i ovisi o stranici
      //na kojoj se trenutačno nalazimo --> $stranica - 1
      echo "<li><a href= 'svi_korisnici0.php?stranica= ". ($stranica-1)."'>&laquo Prethodna </a></li>";
    }
    for ($i=1; $i<=$brojStranica; $i++) {
      if ($i==$stranica) echo "<li class= 'active '><span> $i </span></li>";
      else echo "<li><a href='svi_korisnici0.php?stranica=$i'> $i </a></li> ";
    }
    if ($stranica<$brojStranica){
      echo "<li><a href='svi_korisnici0.php?stranica=" . ($stranica+1) . " '>
      Sljedeća&raquo </a></li>";
    }
    echo "</ul>";
    echo "</div> ";
  }
}
else echo "Nije bilo moguće pročitati bazu";

?>