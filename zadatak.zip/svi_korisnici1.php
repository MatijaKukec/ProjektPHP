
<?php
session_start();
if (!isset($_SESSION['userUid'])) {	header('Location: login.php'); }
$title="Svi korisnici";
include ('header.php');
include ('navbar.php');
		
echo '<div class="forma"><h2>Svi korisnici sustava</h2>';
require_once('baza.php');
$izjava=$veza->prepare('SELECT * FROM korisnici');
if ($izjava->execute()) {
	$rezultat=$izjava->get_result();
	echo "<table>";
	while ($redak=$rezultat->fetch_assoc()) {
		echo "<tr><td>" . $redak['korisnik'] . "</td><td>
		<form action='uredi_korisnik.php' method='post'>
		<input type='hidden' name='id' value='".$redak['id'] . "' />
		<input type='submit' value='Uredi'></input>
		</form> </td><td> <button class ='btn btn-danger' id='".$redak['id'].
		"'data-btn-ok-label='Da' 
		title='Želite li obrisati korisnika?'
		data-btn-cancel-label='Ne' data-toggle='confirmation'
		data-singleton='true'>Obrisi</button></td></tr>";								
		}																	
		echo "</table>";
	}			
$veza->close();	
							
echo "</div>";
include ('paginacija.php');
include('footer.php');
echo "<script>
$('[data-toggle=confirmation]').confirmation({
	rootSelector: '[data-toggle=confirmation]',
	onConfirm: function() {
		location.href='obrisi.php?id=' + $(this).attr('id');
	}
});
document.getElementById('sviKor').classList.add('active'); 
document.getElementById('navbardrop').classList.add('active'); 
</script>";

?>


